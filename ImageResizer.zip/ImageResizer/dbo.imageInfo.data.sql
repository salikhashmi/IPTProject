INSERT INTO [dbo].[imageInfo] ([pkImageId], [imageName]) VALUES (1, N'image1.jpe')
INSERT INTO [dbo].[imageInfo] ([pkImageId], [imageName]) VALUES (2, N'image2.jpe')
INSERT INTO [dbo].[imageInfo] ([pkImageId], [imageName]) VALUES (3, N'image3.jpe')
INSERT INTO [dbo].[imageInfo] ([pkImageId], [imageName]) VALUES (4, N'image4.jpe')
