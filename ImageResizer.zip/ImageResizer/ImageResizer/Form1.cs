﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace ImageResizer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        public SqlConnection conn;
        XmlDocument doc = new XmlDocument();
        private string strconn = @"Data Source=KHURRAMHASHMI\SQLEXPRESS;Initial Catalog=productSales;Integrated Security=True";
        private void button1_Click(object sender, EventArgs e)
        {
            int[] arrayWithImageId = new int[3];

            try
            {
                doc.Load("input.xml");
                XmlElement root = doc.DocumentElement;
                int i = 0;
                foreach (XmlNode node in root.ChildNodes)
                {
                    arrayWithImageId[i] = Convert.ToInt32(node.Attributes["id"].Value);
                    i++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading xml document.  Error: " +
                    ex.ToString());
            }
            conn = new SqlConnection(strconn);
            conn.Open();
            ImageRsize imageObject = new ImageRsize();
            String imageName = "";
           // Image resizedImage;
            SqlDataReader rtnReader;
            for (int index = 0; index < arrayWithImageId.Length; index++)
            { 
                SqlCommand cmd = new SqlCommand("SELECT * from imageInfo WHERE pkImageId = @ID", conn);
                cmd.Parameters.AddWithValue("@ID", arrayWithImageId[index]);
                rtnReader = cmd.ExecuteReader();
                while (rtnReader.Read())
                {
                    MessageBox.Show("The ID is : " + rtnReader["pkImageId"] + " And name is " + rtnReader["imageName"]);
                    imageName = rtnReader["imageName"].ToString();
                }
                imageObject.resizeImage(imageName, index);
                rtnReader.Close();
            }
            conn.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            imagesList imageObject = new imagesList();
            imageObject.Show();
            imageObject.showImages();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ImageAddition imageObject = new ImageAddition();
            imageObject.Show();
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        
        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
