﻿using ImageResizer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ImageResizer
{
    public partial class imagesList : Form
    {
        public imagesList()
        {
            InitializeComponent();
            
        }
        
        XmlDocument doc = new XmlDocument();
        public void showImages()
        {
            int[] arrayWithImageId = new int[20];
            String[] imageNames = new String[20];
            List<String> imageInfo = new List<string>();
            String imageDetail;
            try
            {
                doc.Load("input.xml");
                XmlElement root = doc.DocumentElement;
                int i = 0;
                foreach (XmlNode node in root.ChildNodes)
                {
                    arrayWithImageId[i] = Convert.ToInt32(node.Attributes["id"].Value);
                    imageNames[i] = Convert.ToString(node.Attributes["name"].Value);
                    i++;
                }
                for (int index = 0; index < arrayWithImageId.Length; index++)
                {
                    if (!String.IsNullOrEmpty(imageNames[index]))
                    {
                        imageDetail = arrayWithImageId[index] + "-  " + imageNames[index];
                        imageInfo.Add(imageDetail);
                    }
                }
                comboBox1.DataSource = imageInfo;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading xml document.  Error: " +
                    ex.ToString());
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
