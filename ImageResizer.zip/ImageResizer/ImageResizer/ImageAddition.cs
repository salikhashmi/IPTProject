﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ImageResizer
{
    public partial class ImageAddition : Form
    {
        public ImageAddition()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public SqlConnection conn;
        XmlDocument doc = new XmlDocument();
        private string strconn = @"Data Source=KHURRAMHASHMI\SQLEXPRESS;Initial Catalog=productSales;Integrated Security=True";
        private void button1_Click(object sender, EventArgs e)
        {

            int[] arrayWithImageId = new int[20];
            String[] imageNames = new String[20];
            int idCount =2 ;
            try
            {
                doc.Load("input.xml");
                XmlElement root = doc.DocumentElement;
                int i = 0;
                foreach (XmlNode node in root.ChildNodes)
                {
                    arrayWithImageId[i] = Convert.ToInt32(node.Attributes["id"].Value);
                    imageNames[i] = node.Attributes["name"].Value.ToString();
                    i++;
                }
                idCount = i+1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading xml document.  Error: " +
                    ex.ToString());
            }
            try
            {
                doc.Load("input.xml");
                XmlElement root = doc.DocumentElement;
                XmlNode Image = doc.CreateElement("Image");
                XmlElement el = (XmlElement)Image;
                el.SetAttribute("id", idCount.ToString());
                el.SetAttribute("name", textBox3.Text);
                root.AppendChild(Image);
                MessageBox.Show("The image has been Added in the XML.");
                doc.Save("input.xml");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading xml document.  Error: " +
                    ex.ToString());

            }
            ImageRsize imageObject = new ImageRsize();
            for (int index = 0; index < idCount-1; index++)
            {
                imageObject.resizeImage(imageNames[index], index);
            }
            
        }
    }
}
