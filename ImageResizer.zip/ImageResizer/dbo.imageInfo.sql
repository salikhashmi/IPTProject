﻿CREATE TABLE [dbo].[imageInfo] (
    [pkImageId] INT NOT NULL, 
    [imageName] NTEXT NOT NULL,
);

